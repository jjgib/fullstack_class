const express = require('express');
const hbs = require('hbs');

var app = express();
// app.get('/', (req,res)=>{
//     res.send("Welcome to My Web page");
// });

// app.get('/about', (req,res)=> {
//     res.send("About us");
// });

app.set('view engine','hbs');
app.get('/home',(req,res)=>{
    res.render('home.hbs');
});
app.get('/about',(req,res)=>{
    res.render('about.hbs');
});

app.post('/getUsers',(req,res)=>{
    res.send({
        "name":"Joseph",
        "age":20,
        "likes":[
            'Biking','Reading'
        ]
    });
});

app.listen(3000);