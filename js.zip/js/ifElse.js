var a = 10;
if(a < 20){
    console.log("a is less than 20");
}
else {
    console.log("a is greater than 20");
}