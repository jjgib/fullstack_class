var a = 20;
if(a % 2 == 0){
    console.log("a is Even number");
}
else {
    console.log("a is Odd number");
}