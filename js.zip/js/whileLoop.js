var i = 1;
while(i <= 100){
    console.log(i);
    i++;
}