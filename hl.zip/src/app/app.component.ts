import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular programming';
  myName = "";
  myRoll = "";
  name = "Gibil";
  location:string = "Angamaly";
  status:boolean = false;

  constructor(){
    setTimeout(() => {
      this.status = true;
    }, 10000);
  }
  clickme=()=>{
    this.status = false;
  }

  onSubmit(form:NgForm){
    this.myName = form.value.getName;
    this.myRoll = form.value.getRoll;
  }
}
