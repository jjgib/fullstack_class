module.exports.getStudent=(x)=>{
    return x;
}