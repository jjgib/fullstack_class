// const ModuleOs = require('os');
// const ModuleFs = require('fs');
// var MyUser = ModuleOs.userInfo();
// ModuleFs.appendFile('hello.txt','Welcome to node',
//     function(err){
//         if(err) throw err;
//         console.log('File saved successfully');
//     }
// );
// console.log(ModuleFs);

// const myModule = require('./students.js');
// var name = myModule.getStudent('Joseph');
// console.log(name);

// const addModule = require('./add.js');
// var addNum = addModule.addNum(2,3);
// console.log(addNum);

const _ = require('lodash');
var myArray = _.uniq(['Gibil',123,123,'Gibil']);
console.log(myArray);