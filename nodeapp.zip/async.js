//Example for non blocking I/O
console.log('Order Taking Started');
setTimeout( ()=> {
    console.log('Table 1 order');
},5000);

setTimeout( ()=>{
    console.log('Table 2 order');
},2000);