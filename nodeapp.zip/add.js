module.exports.addNum=(x,y)=>{
    return x+y;
}