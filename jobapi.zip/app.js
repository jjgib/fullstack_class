const express = require('express');
var bodyParser = require('body-parser');

var {mongoose} = require('./mongoose_db');
var {Jobs} = require('./jobModels');

var app = express();
app.use(bodyParser.json());

// For CORS,Pgm Line no 12 to 29
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200' );

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});

//Fetch data
app.get('/getjobs',(req,res)=>{
    Jobs.find().then( (data)=>{
        res.send(data);
    }, (error)=>{
        res.status(400).send("Error happened "+error);
    })
})

//Create
app.post('/save',(req,res)=>{
    var jobs = new Jobs(
        {
            jobTitle : req.body.jobtitle,
            jobDescription : req.body.jobdesc,
            companyName : req.body.companyname,
            jobLocation : req.body.joblocation,
            jobField : req.body.jobfield,
            employmentType : req.body.emp_type
        }
    );
    jobs.save().then( (doc)=>{
        res.send(doc);
    }, (error)=>{
        res.status(400).send(error);
    })
});

//Find by Id
app.get('/view/:jobId',(req,res)=>{
    var id = req.params.jobId;
    Jobs.findById(id)
    .then( (result)=>{
        if(result){
            res.send(result);
        }
        else {
            res.status(404).json({message:'No valid entry found for provided ID'});
        }
    })
    .catch( (e)=>{
        res.status(500).json( {error: e} );
    });
});

//Update
app.patch('/update/:jobId',(req,res)=>{
    var id = req.params.jobId;
    var jobdetails = {
        jobTitle : req.body.jobtitle,
        jobDescription : req.body.jobdesc,
        companyName : req.body.companyname,
        jobLocation : req.body.joblocation,
        jobField : req.body.jobfield,
        employmentType : req.body.emp_type
    };
    // var jobdetails = {};
    // for (const ops of req.body){
    //     jobdetails[ops.propName] = ops.value;
    // }

    Jobs.findByIdAndUpdate(id,jobdetails)
    .then( (result)=>{
        res.send(result);
    })
    .catch( (err)=>{
        res.status(500).json({
            error: err
        });
    });
});

//Delete
app.delete('/delete/:jobId',(req,res)=>{
    var id = req.params.jobId;
    //Jobs.remove({ _id: id})
    Jobs.findOneAndRemove({ _id:id })
    .then( (result)=>{
        //res.status(200).json(result)
        res.send(result);
    })
    .catch( (err)=>{
        res.status(500).json({
            error:err
        })
    });
});

app.listen(3000,()=>{
    console.log('Server started successfully');
});